<?php
//-----------------------------------------------//
// Wysylanie danych poprzez formularz kontaktowy //
// ----------------------------------------------//
// przesyla dane z formularza kontaktowego
include "cfg.php";
PokazKontakt();
if (isset($_POST['Wyslij'])) {
    WyslijMailKontakt('krysd246@gmail.com');
}
if (isset($_POST['PrzypomnijHaslo'])) {
    PrzypomnijHaslo('krysd246@gmail.com');
}
function WyslijMailKontakt($odbiorca)
{
    if (empty($_POST['temat']) || empty($_POST['tresc']) || empty($_POST['email'])) {
        echo '[nie_wypelniles_pola]';
        echo PokazKontakt(); //ponowne wysylanie formularza
    } else {
        $temat = htmlspecialchars($_POST['temat']); //zabezpieczenie przed code injection
        $tresc = htmlspecialchars($_POST['tresc']); //zabezpieczenie przed code injection
        $email = htmlspecialchars($_POST['email']); //zabezpieczenie przed code injection
        $mail['subject'] = $temat;
        $mail['body'] = $tresc;
        $mail['sender'] = $email;
        $mail['reciptient'] = $odbiorca; //czyli my jesesmy odbiorca jeżeli tworzymy formularz kontaktowy
        $header = "From: Formularz kontaktowy <" . $mail['sender'] . ">\n";
        $header .= "MIME-Version; 1.0\nContent-Type: text/plain; charset=utf-8\nContent-Transfer-Encoding: 8bit\n";
        $header .= "X-Sender: <" . $mail['sender'] . ">\n";
        $header .= "X-Mailer: PRapWWW mail 1.2\n";
        $header .= "X-Priority: 3\n";
        $header .= "Return-Path: <" . $mail['sender'] . ">\n";
        mail($mail['reciptient'], $mail['subject'], $mail['body'], $header);
        echo '<script>window.alert("Wysłano!")</script>';
    }
}

function PokazKontakt()
{
    echo '<form method="post" action=""><label for="temat">Temat:</label>';
    echo '<input type="text" name="temat" required><br>';
    echo '<label for="tresc">Treść:</label>';
    echo '<textarea name="tresc" required></textarea><br><label for="email">Twój e-mail:</label>';
    echo '<input type="email" name="email" required><br><br>';
    echo '<input type="submit" name="Wyslij" value="Wyslij"><br><br>';
    echo '</form>';
    echo '<form method="post" action="">';
    echo '<input type="submit" name="PrzypomnijHaslo" value="Przypomnij haslo"><br><br>';
    echo '</form>';
}

function PrzypomnijHaslo($odbiorca)
{
    global $pass;
    $mail['subject'] = 'Przypomnienie hasla';
    $mail['body'] = "Haslo: " . $pass;
    $mail['reciptient'] = $odbiorca;
    $mail['sender'] = $odbiorca;
    $header = "From: Formularz kontaktowy <" . $mail['sender'] . ">\n";
    $header .= "MIME-Version; 1.0\nContent-Type: text/plain; charset=utf-8\nContent-Transfer-Encoding: 8bit\n";
    $header .= "X-Sender: <" . $mail['sender'] . ">\n";
    $header .= "X-Mailer: PRapWWW mail 1.2\n";
    $header .= "X-Priority: 3\n";
    $header .= "Return-Path: <" . $mail['sender'] . ">\n";
    mail($mail['reciptient'], $mail['subject'], $mail['body'], $header);
    echo '<script>window.alert("Wysłano!")</script>';
}

?>
