<?
//PokazKontakt()
//PrzypomnijHaslo()
//-----------------------------------------------//
// Wysylanie danych poprzez formularz kontaktowy //
// ----------------------------------------------//
// przesyla dane z formularza kontaktowego

function WyslijMailKontakt($odbiorca)
{
	if(empty($_POST['temat']) || empty($_POST['tresc']) || empty($_POST['email']))
	{
		echo '[nie_wypelniles_pola]';
		echo PokazKontakt(); //ponowne wysylanie formularza
	}
	else
	{
		$mail['subject'] = $_POST['temat'];
		$mail['body']    = $_POST['tresc'];
		$mail['sender']  = $_POST['email'];
		$mail['reciptient'] = $odbiorca; //czyli my jesesmy odbiorca jeżeli tworzymy formularz kontaktowy
		
		$header = "From: Formularz kontaktowy <".$mail['sender'].">\n";
		$header .= "MIME-Version; 1.0\nContent-Type: text/plain; charset-utf-8\nContent-Transfer-Encoding:";
		$header .= "X-Sender: <".$mail['sender'].">\n;
		$header .= "X-Mailer: PRapWWW mail 1.2\n";
		$header .= "X-Priority: 3\n";
		$header .= "Return-Path: <".$mail['sender'].">\n";
		
		mail($mail['reciptient'],$mail['subject'],$mail['body'],$header);
		
		echo '[wiadomosc_wyslana]';
	}
}
?>
