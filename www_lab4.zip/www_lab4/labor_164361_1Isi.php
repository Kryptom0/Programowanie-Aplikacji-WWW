<?php
//Zadanie1
 $nr_indeksu = '164361';
 $nrGrupy = 'IISI';
 echo 'Krystian Drzaszcz '.$nr_indeksu. 'grupa '.$nrGrupy.' <br /><br />';
 //Zadanie2_a)
 echo 'Zadanie 2a <br />';
 echo 'Test Metoda include <br />';
 $color = '';
 $fruit = '';
 echo "A $color $fruit <br />";
 include 'vars.php';
 echo "A $color $fruit <br />";
 echo 'Test Metoda require_once <br />';
 $b = require_once('require_once.php');
 echo "$b <br />";
 //Zadanie2_b)
 echo 'Zadanie 2b <br />';
 echo 'Test if <br />';
 $x = 5;
 $y = 10;
 if ($x < $y)
	 echo "$x jest mniejszy od $y <br />";
 echo 'Test ifelse <br />';
 if ($x > $y){
	 echo "$x jest większy od $y <br />";
 } else{
	 echo "$y jest większy od $x <br />";
 }
 echo 'Test if, ifelse, else <br />';
 if ($x > $y) {
     echo "$x jest większy od $y <br />";
 } elseif ($x == $y) {
     echo "$x jest równy $y <br />";
 } else {
     echo "$x jest mniejszy od $y <br />";
 }
 $z = 2;
 echo 'Test switch <br />';
switch ($z) {
    case 0:
        echo "z = 0 <br />";
        break;
    case 1:
        echo "z = 1 <br />";
        break;
    case 2:
        echo "z = 2 <br />";
        break;
}
 //Zadanie2_c)
 echo 'Zadanie 2c <br />';
 echo 'Test while  <br />';
 while ($z <=12){
	echo $z;
	$z++;
 }
 echo '<br />';
 echo 'Test for  <br />';
 for ($z = 4; $z <= 10; $z++) {
	echo $z;
 }
 echo "<br />";
 //Zadanie2_d)
 echo 'Zadanie 2d <br />';
 echo 'Test $_get <br />';
 echo 'Hello ' . htmlspecialchars($_GET["name"]) . '! <br />';
?>