<?php
return "Test require";
?>