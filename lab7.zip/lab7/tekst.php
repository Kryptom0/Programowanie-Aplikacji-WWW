<?
	$query="SELECT * FROM page_list WHERE id='$id_clear' ORDER BY data DESC LIMIT 100";
	 $result = my_sql_query($query);
	 
	  while($row = mysql_fetch_array($result))
	  {
		$row['id'].' '.$row['tytul']. ' <br />';
	  }

?>	  